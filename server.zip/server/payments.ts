import Stripe from "stripe";
import type { Request, Response } from "express";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, {
  apiVersion: "2025-09-30.clover",
});

export async function createPaymentIntent(req: Request, res: Response) {
  try {
    const { amount, currency } = req.body;
    if (!amount) return res.status(400).json({ error: "Missing amount" });

    const intent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100), // cents
      currency: currency || "usd",
      automatic_payment_methods: { enabled: true },
    });

    res.json({ clientSecret: intent.client_secret });
  } catch (err: any) {
    console.error("Stripe error:", err);
    res.status(500).json({ error: err.message });
  }
}
